import React from "react";
import { motion } from "framer-motion";
import { Code, Cpu, Smartphone, Mail } from "lucide-react";

export default function NiccoloMachiavelliSite() {
  return (
    <div className="min-h-screen bg-[#0b0b0b] text-gray-100 font-sans relative">
      {/* Small Picture Top Right (SVG Monogram) */}
      <div className="absolute top-4 right-6" aria-hidden="true">
        <div className="w-14 h-14 rounded-full p-0.5 bg-gradient-to-br from-gray-700 via-gray-900 to-black ring-1 ring-white/5 shadow-lg" style={{boxShadow: '0 8px 30px rgba(2,6,23,0.6)'}}>
          <div className="w-full h-full rounded-full bg-[#0b0b0b] flex items-center justify-center overflow-hidden">
            {/* SVG Monogram (NM) - white/ash on dark background */}
            <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Niccolo Machiavelli monogram">
              <defs>
                <linearGradient id="g1" x1="0" x2="1" y1="0" y2="1">
                  <stop offset="0%" stopColor="#E6E7E9" />
                  <stop offset="100%" stopColor="#9CA3AF" />
                </linearGradient>
              </defs>
              <rect width="56" height="56" rx="28" fill="#0b0b0b" />
              <g transform="translate(8,9)">
                <path d="M6 0h6l8 16V0h6v32h-6l-8-16v16H6V0z" fill="url(#g1)" />
                <text x="28" y="28" textAnchor="middle" fontFamily="'Inter', sans-serif" fontWeight="700" fontSize="14" fill="url(#g1)" style={{dominantBaseline: 'central'}}>NM</text>
              </g>
            </svg>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="flex justify-between items-center px-8 py-6 border-b border-gray-800">
        <h1 className="text-2xl font-bold tracking-wide">
          NICCOLÓ MACHIAVELLI <span className="text-gray-400">(Akash)</span>
        </h1>
        <nav className="space-x-6 text-gray-300">
          <a href="#services" className="hover:text-white transition">Services</a>
          <a href="#about" className="hover:text-white transition">About</a>
          <a href="#contact" className="hover:text-white transition">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-24 px-6">
        <motion.h2 
          initial={{ opacity: 0, y: 30 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold mb-6"
        >
          Modern Technical Solutions
        </motion.h2>
        <p className="text-lg text-gray-400 max-w-2xl mx-auto">
          Providing cutting-edge services with a focus on innovation, technology, and reliability.
        </p>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-8 bg-[#121212]">
        <h3 className="text-3xl font-semibold text-center mb-12">Our Services</h3>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <motion.div whileHover={{ scale: 1.05 }} className="p-6 bg-[#1a1a1a] rounded-2xl shadow-md">
            <Code className="h-10 w-10 mb-4 text-gray-400" />
            <h4 className="text-xl font-bold mb-2">Web Development</h4>
            <p className="text-gray-400">Building responsive and scalable web applications with modern stacks.</p>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} className="p-6 bg-[#1a1a1a] rounded-2xl shadow-md">
            <Cpu className="h-10 w-10 mb-4 text-gray-400" />
            <h4 className="text-xl font-bold mb-2">AI & Automation</h4>
            <p className="text-gray-400">Smart solutions leveraging AI, ML, and process automation tools.</p>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} className="p-6 bg-[#1a1a1a] rounded-2xl shadow-md">
            <Smartphone className="h-10 w-10 mb-4 text-gray-400" />
            <h4 className="text-xl font-bold mb-2">App Development</h4>
            <p className="text-gray-400">Mobile applications with sleek designs and robust performance.</p>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-semibold mb-6">About NICCOLÓ MACHIAVELLI (Akash)</h3>
          <p className="text-gray-400 leading-relaxed mb-6">
            We are a service provider dedicated to delivering high-quality technical solutions. With a passion for
            innovation and a focus on client satisfaction, our team brings modern, reliable, and creative ideas to life.
          </p>
          <p className="text-gray-400 leading-relaxed mb-6">
            Our philosophy is simple — blend strategy with execution. We don’t just build websites or apps, we design
            experiences that are fast, scalable, and intuitive. Every line of code we write, every design decision we
            make, is driven by clarity and performance.
          </p>
          <p className="text-gray-400 leading-relaxed">
            Over the years, we have worked with entrepreneurs, creators, and businesses to help them establish a strong
            digital presence. Whether it’s creating a modern web platform, automating workflows, or building powerful
            mobile applications — we ensure every project reflects innovation and excellence.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-8 bg-[#121212]">
        <h3 className="text-3xl font-semibold text-center mb-12">Get in Touch</h3>
        <div className="max-w-xl mx-auto text-center">
          <Mail className="h-12 w-12 mx-auto mb-6 text-gray-400" />
          <p className="text-gray-400 mb-6">
            Interested in working together? Contact us for collaborations or service inquiries.
          </p>
          <a
            href="mailto:drscorpion761@gmail.com"
            className="inline-block px-6 py-3 rounded-xl bg-gray-100 text-black font-semibold hover:bg-white transition"
          >
            Send Email
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-500 border-t border-gray-800">
        © {new Date().getFullYear()} NICCOLÓ MACHIAVELLI (Akash). All rights reserved.
      </footer>
    </div>
  );
}
