NICCOLÓ MACHIAVELLI (Akash) - Service Landing Page
==================================================

This is a minimal React component for a modern, technical landing page (black/ash/white theme) with an embedded SVG monogram.

Files included:
- src/NiccoloMachiavelliSite.jsx  -- React component (ready to paste into a React project)
- monogram.svg                    -- Standalone SVG monogram (NM)
- package.json                    -- Example package.json listing main deps
- README.md                       -- This file

How to use:
1. Create a React app (e.g., using create-react-app).
2. Place `src/NiccoloMachiavelliSite.jsx` into `src/` and import it in App.js.
3. Install dependencies: `npm install`.
4. Start: `npm start`.

If you want, I can also create a full repo with Tailwind setup and a deployable template.